#!/bin/bash
cd /usr/aplayer
sudo ./aplayer
